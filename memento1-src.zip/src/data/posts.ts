/**
 * 메멘토애니 게시글 및 컨텐츠 데이터
 */

import { CommunityPost, AdoptionPost, PetcareGuide, MemorialCard, PostCollections } from '@/types'

export const communityBestPosts: CommunityPost[] = [
  {
    title: "우리집 골든리트리버 훈련 성공기",
    author: "멍멍맘",
    likes: 234,
    comments: 45,
    badge: "인기",
  },
  {
    title: "강아지 산책 필수템 추천",
    author: "산책러버",
    likes: 189,
    comments: 32,
    badge: "꿀팁",
  },
  {
    title: "고양이 사료 바꾸기 도전기",
    author: "냥집사",
    likes: 156,
    comments: 28,
    badge: "후기",
  },
  {
    title: "첫 펫샵 방문 후기",
    author: "초보집사",
    likes: 98,
    comments: 15,
    badge: "신규",
  },
  {
    title: "우리 강아지 미용 변신기",
    author: "미용러버",
    likes: 87,
    comments: 22,
    badge: "변신",
  },
]

export const adoptionPosts: AdoptionPost[] = [
  {
    title: "믹스견 무료분양 (서울 강남)",
    location: "강남구",
    age: "6개월",
    badge: "긴급",
  },
  {
    title: "페르시안 고양이 입양하실 분",
    location: "마포구",
    age: "2세",
    badge: "신규",
  },
  {
    title: "보호소 방문 후기",
    location: "성남시",
    age: "성견",
    badge: "후기",
  },
  {
    title: "말티즈 분양합니다",
    location: "서초구",
    age: "3개월",
    badge: "분양",
  },
  {
    title: "치와와 임시보호 도움",
    location: "용산구",
    age: "1세",
    badge: "도움",
  },
  {
    title: "진돗개 입양 문의",
    location: "송파구",
    age: "2세",
    badge: "문의",
  },
  {
    title: "러시안블루 분양",
    location: "종로구",
    age: "4개월",
    badge: "블루",
  },
]

export const petcareGuides: PetcareGuide[] = [
  {
    title: "강아지 예방접종 스케줄 가이드",
    category: "건강관리",
    difficulty: "기초",
    badge: "필수",
  },
  {
    title: "고양이 털갈이 시기 관리법",
    category: "일상케어",
    difficulty: "쉬움",
    badge: "계절",
  },
  {
    title: "반려견 기본 훈련 5단계",
    category: "훈련",
    difficulty: "보통",
    badge: "인기",
  },
  {
    title: "펫 응급상황 대처 방법",
    category: "응급처치",
    difficulty: "중요",
    badge: "응급",
  },
  {
    title: "나이별 사료 선택 가이드",
    category: "영양관리",
    difficulty: "쉬움",
    badge: "영양",
  },
  {
    title: "실내 고양이 운동법",
    category: "운동",
    difficulty: "보통",
    badge: "운동",
  },
  {
    title: "펫 치과 건강 관리",
    category: "건강관리",
    difficulty: "중요",
    badge: "건강",
  },
]

export const memorialCards: MemorialCard[] = [
  {
    name: "꼼지",
    pet: "요크셔테리어", 
    years: "2008-2023",
    message: "15년간 함께한 소중한 추억",
    emoji: "🐕",
  },
  {
    name: "마루",
    pet: "골든리트리버",
    years: "2015-2024", 
    message: "영원히 마음속에 남을 친구",
    emoji: "🦮",
  },
  {
    name: "나비",
    pet: "페르시안 고양이",
    years: "2010-2023",
    message: "고운 마음으로 기억할게", 
    emoji: "🐱",
  },
  {
    name: "초코",
    pet: "말티즈",
    years: "2012-2024",
    message: "항상 곁에 있는 것 같아",
    emoji: "🐶",
  },
  {
    name: "루비", 
    pet: "러시안블루",
    years: "2016-2024",
    message: "사랑스러운 우리 공주님",
    emoji: "😺",
  },
  {
    name: "몽이",
    pet: "푸들", 
    years: "2014-2024",
    message: "천사같던 우리 아기",
    emoji: "🐩",
  },
  {
    name: "별이",
    pet: "스코티시폴드",
    years: "2013-2023", 
    message: "하늘나라에서 잘 지내",
    emoji: "⭐",
  },
]

export const allCommunityPosts: CommunityPost[] = [
  {
    title: "우리집 골든리트리버 훈련 성공기",
    author: "멍멍맘",
    category: "훈련팁",
    badge: "인기",
    preview: "8개월된 골든리트리버 맥스를 키우면서 겪었던 훈련 과정을 공유해요...",
    likes: 234,
    comments: 45,
    views: 1250,
    time: "2시간 전"
  },
  {
    title: "강아지 산책 필수템 추천",
    author: "산책러버",
    category: "정보공유",
    badge: "꿀팁",
    preview: "매일 산책하면서 정말 유용했던 아이템들을 소개해드려요...",
    likes: 189,
    comments: 32,
    views: 890,
    time: "5시간 전"
  },
  {
    title: "고양이 사료 바꾸기 도전기",
    author: "냥집사",
    category: "일상공유",
    badge: "후기",
    preview: "우리 냥이가 기존 사료를 안 먹어서 새로운 사료로 바꾸는 과정을 기록해봤어요...",
    likes: 156,
    comments: 28,
    views: 634,
    time: "8시간 전"
  },
  {
    title: "응급실 다녀온 후기 (중요)",
    author: "걱정맘",
    category: "병원후기",
    badge: "응급",
    preview: "어제 밤에 우리 강아지가 갑자기 구토를 해서 24시 병원에 다녀왔어요...",
    likes: 98,
    comments: 67,
    views: 2340,
    time: "12시간 전"
  },
  {
    title: "첫 강아지 입양 준비물 체크리스트",
    author: "초보집사",
    category: "정보공유",
    badge: "신규",
    preview: "다음 주에 첫 강아지를 입양할 예정인데, 미리 준비해야 할 것들을 정리해봤어요...",
    likes: 87,
    comments: 43,
    views: 567,
    time: "1일 전"
  },
  {
    title: "우리 멍멍이 미용 변신기",
    author: "미용러버",
    category: "일상공유",
    badge: "변신",
    preview: "3개월만에 미용샵 다녀왔는데 완전 다른 강아지가 되었어요...",
    likes: 76,
    comments: 22,
    views: 445,
    time: "1일 전"
  },
  {
    title: "반려견과 제주도 여행 꿀팁",
    author: "여행러버",
    category: "정보공유",
    badge: "여행",
    preview: "강아지와 함께 제주도 3박4일 다녀왔어요! 펫프렌들리 숙소부터 맛집까지...",
    likes: 65,
    comments: 18,
    views: 789,
    time: "2일 전"
  }
]

export const bestPosts: PostCollections = {
  community: communityBestPosts,
  adoption: adoptionPosts,
  petcare: petcareGuides,
}

export const communityCategories = [
  '전체', '일상공유', '질문답변', '정보공유', '병원후기', '훈련팁', '자유게시판'
]

export const noticeList = [
  '커뮤니티 이용규칙 안내',
  '반려동물 응급상황 신고 가이드', 
  '허위 분양글 신고 방법',
  '메멘토애니 새 기능 업데이트'
]
